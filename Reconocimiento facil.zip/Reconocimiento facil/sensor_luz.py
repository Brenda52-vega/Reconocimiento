"""
    Integrantes:
        Enríquez Barrera Marisol
        Vega Piña Brenda Edith

    Objetivo
Capturar una imagen con la cámara y evalúe si la iluminación ambiental es suficiente,
estimando el porcentaje de píxeles brillantes en la imagen. 

"""
import camera
import time

# Función para evaluar si la luz ambiente supera un umbral dado (%)
def evaluar_luz_umbral(umbral=20):
    print("📸 Capturando imagen para evaluar luz...")

    try:
        # Toma una fotografía con la cámara
        img = camera.capture()
        if not img:
            # Si no se recibió ningún byte de imagen, informa y devuelve False
            print("❌ No se pudo capturar imagen")
            return False

        # Estimación simple del brillo: cuenta cuántos bytes tienen valor > 127
        # (suponiendo que un byte alto indica píxel relativamente brillante)
        count_brillante = sum(1 for b in img if b > 127)
        # Calcula el porcentaje de píxeles brillantes sobre el total de bytes recibidos
        brillo_estimado = (count_brillante / len(img)) * 100

        # Muestra el porcentaje de brillo estimado
        print("💡 Brillo estimado: %.2f%%" % brillo_estimado)

        # Devuelve True si el brillo sobrepasa el umbral, en caso contrario False
        return brillo_estimado > umbral

    except Exception as e:
        # Si ocurre cualquier excepción durante la captura o el análisis de bytes
        print("⚠️ Error al analizar luz:", e)
        return False

