"""
    Integrantes:
        Enríquez Barrera Marisol
        Vega Piña Brenda Edith

    Objetivo
Implementa funciones para medir la distancia a un
objeto utilizando un sensor ultrasónico HC-SR04 

"""
from machine import Pin, time_pulse_us
import time

# ----------------------------------------
# Configuración de pines para HC-SR04
# ----------------------------------------
trig = Pin(4, Pin.OUT)  # Pin 4 configurado como salida para el pulso TRIG
echo = Pin(2, Pin.IN)   # Pin 2 configurado como entrada para leer el pulso ECHO

# ----------------------------------------
# Función para medir la distancia usando HC-SR04
# ----------------------------------------
def medir_distancia():
    # Asegurarse de que TRIG comience en bajo
    trig.value(0)
    time.sleep_us(2)       # Esperar 2 microsegundos para estabilizar

    # Enviar un pulso alto de 10 microsegundos al pin TRIG
    trig.value(1)
    time.sleep_us(10)      # Mantener TRIG en alto durante 10 µs
    trig.value(0)          # Volver a poner TRIG en bajo

    try:
        # time_pulse_us mide el tiempo (en µs) que el pin ECHO permanece en 1
        # El tercer parámetro (30000) es el timeout en µs (30 ms -> aproximadamente 5 m)
        duracion = time_pulse_us(echo, 1, 30000)

        # Convertir tiempo de viaje del pulso a distancia en centímetros
        # velocidad del sonido ~343 m/s -> 0.0343 cm/µs
        # Se divide entre 2 porque el pulso recorre ida y vuelta
        distancia = duracion * 0.0343 / 2

        # Redondear a 2 decimales y devolver la distancia medida
        return round(distancia, 2)

    except OSError:
        # Si ocurre error (por ejemplo, timeout porque no llegó pulso ECHO)
        print("⚠️ Error al medir distancia")
        return float("inf")  # Devolver infinito para indicar que no se detectó ningún objeto

# ----------------------------------------
# Función para determinar si hay persona cerca
# ----------------------------------------
def persona_detectada(umbral=100):
    # Llama a medir_distancia() para obtener la distancia medida en cm
    d = medir_distancia()
    print("📏 Distancia medida:", d, "cm")

    # Retorna True si la distancia es menor al umbral (cm),
    # es decir, si algo (persona) está más cerca que el umbral
    return d < umbral

