"""
    Integrantes:
        Enríquez Barrera Marisol
        Vega Piña Brenda Edith

    Objetivo
Configurar y preparar el sistema de hardware (relé, LED, buzzer, cámara)
y establecer conexión Wi-Fi.

"""
import network
import time
import camera
from machine import Pin

# ==== Definición y configuración de pines ====
# Pin 12: módulo de relé (activo en LOW, por eso value=1 para que inicie "desactivado")
rele = Pin(12, Pin.OUT, value=1)
# Pin 13: LED azul para indicar acceso autorizado
led_ok = Pin(13, Pin.OUT, value=0)
# Pin 14: Buzzer para señal auditiva
buzzer = Pin(14, Pin.OUT, value=0)

# ==== Configuración y conexión a red Wi-Fi ====
# Se crea la interfaz Wi-Fi en modo estación (STA_IF)
sta = network.WLAN(network.STA_IF)
sta.active(True)  # Activa la interfaz Wi-Fi

# Inicia la conexión a la red, reemplaza SSID y contraseña según corresponda
sta.connect("INFINITUM64D2", "ingR3$0Pin452")
# Espera en bucle hasta obtener una IP (conexion exitosa)
while not sta.isconnected():
    time.sleep(1)  # Pausa de 1 segundo en cada iteración

# Imprime la IP asignada una vez conectado
print("✅ WiFi conectado:", sta.ifconfig()[0])

# ==== Inicialización de la cámara ====  
try:
    # Si la cámara ya estaba inicializada, se desinicializa primero
    camera.deinit()
except:
    # Si falla al desinicializar.
    pass

time.sleep(1)  # Breve espera para asegurar que la desinicialización se complete

# Inicializa la cámara en modo JPEG (sensor 0)
camera.init(0, format=camera.JPEG)
# Ajusta la resolución de captura a QVGA (320×240) para balancear calidad/velocidad
camera.framesize(camera.FRAME_QVGA)

