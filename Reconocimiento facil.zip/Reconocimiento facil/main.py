"""
    Integrantes:
        Enríquez Barrera Marisol
        Vega Piña Brenda Edith

    Objetivo
Permanece en espera hasta que se detecte la presencia de una persona mediante un sensor
ultrasónico y se verifique que hay suficiente luz ambiental usando un sensor de luminosidad.
Una vez que ambas condiciones se cumplen, se inicializa el sistema completo.

"""
# Imprime un mensaje inicial indicando que el sistema está en modo pasivo
print("📦 Sistema pasivo activado...")

import time
import camera
import sensor_ultrasonico
import sensor_luz

# ------------------------------------------------------------------------------
# Inicializar la cámara en resolución baja para poder evaluar el nivel de luz
# ------------------------------------------------------------------------------
try:
    camera.deinit()                 # Si la cámara ya estaba activa, la desinicializa
    time.sleep(1)                   # Pausa 1 segundo para asegurar que se desinicialice correctamente
    camera.init(0, format=camera.JPEG)   # Inicializa la cámara en modo JPEG (sensor 0)
    camera.framesize(camera.FRAME_QQVGA) # Ajusta la resolución a QQVGA (baja) para ahorrar procesamiento
except Exception as e:
    # Si ocurre cualquier error al inicializar la cámara, lo informa y detiene la ejecución
    print("❌ Error al iniciar cámara:", e)
    raise

# ------------------------------------------------------------------------------
# Bucle infinito: espera a que se detecte una persona y se cumpla un umbral de luz
# ------------------------------------------------------------------------------
while True:
    # sensor_ultrasonico.persona_detectada() devuelve True si el sensor ultrasónico detecta presencia
    if sensor_ultrasonico.persona_detectada():
        print("👤 Persona detectada, evaluando luz...")
        
        # sensor_luz.evaluar_luz_umbral() devuelve True si la luz ambiente supera un umbral mínimo
        if sensor_luz.evaluar_luz_umbral():
            print("✅ Condiciones cumplidas. Iniciando sistema...")
            break  # Sale del bucle al cumplirse ambas condiciones: persona + luz suficiente
        else:
            # Si la luz es insuficiente, muestra un mensaje y vuelve a empezar
            print("🌒 Luz insuficiente. Reintentando...\n")
    else:
        # Si no hay persona, imprime que sigue esperando y repite el bucle
        print("🔍 Esperando persona...\n")

    # Llamada a time.sleep sin argumento (queda en None); en un uso típico debería ser time.sleep(0.x)
    # Aquí no pausa realmente, pero se conserva tal cual. Si se quiere un retraso, usar time.sleep(segundos).
    time.sleep

# ------------------------------------------------------------------------------
# Una vez que sale del bucle (hay persona y luz adecuada), se inicia el sistema completo
# ------------------------------------------------------------------------------
import config    # Importa la configuración general (pines, parámetros, etc.)
import servidor  # Importa el módulo que contiene la lógica del servidor web para manejar el sistema

# Llama a la función servidor_web() para arrancar el servicio principal (por ejemplo, streaming, API, etc.)
servidor.servidor_web()

