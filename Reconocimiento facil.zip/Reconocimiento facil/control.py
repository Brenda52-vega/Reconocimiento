"""
    Integrantes:
        Enríquez Barrera Marisol
        Vega Piña Brenda Edith

    Objetivo
Se gestionan el relé, el LED y el buzzer para indicar si el acceso es autorizado o denegado.

"""
import time
from machine import Pin
from config import rele, led_ok, led_err, buzzer

# Función para activar el buzzer durante un tiempo 't' (en segundos)
def sonar_buzzer(t=0.2):
    buzzer.value(1)        # Enciende el buzzer (valor alto)
    time.sleep(t)          # Mantiene el buzzer encendido durante 't' segundos
    buzzer.value(0)        # Apaga el buzzer (valor bajo)

# Función que gestiona el relé y la señalización según si 'valido' es True o False
def activar_rele(valido):
    if valido:
        # ---------------------------------------------
        # Bloque para acceso autorizado (valido == True)
        # ---------------------------------------------
        print("🔓 Acceso autorizado")
        
        # Configura el pin de control del relé como salida
        rele.init(Pin.OUT)
        # Activa el relé: conecta IN a GND (valor 0), energizando la bobina
        rele.value(0)
        
        # Enciende el LED verde para indicar acceso permitido
        led_ok.value(1)
        # Suena el buzzer brevemente como señal de aprobación
        sonar_buzzer(0.2)

        # Mantiene el relé activo durante 5 segundos (la chapa permanece abierta)
        time.sleep(5)

        # Apaga el LED verde al finalizar el tiempo de activación
        led_ok.value(0)
        # Para “desconectar” el relé, vuelve a poner el pin en modo entrada.
        # Así se interrumpe la corriente y la chapa deja de estar energizada.
        rele.init(Pin.IN)
        print("🔒 Relé desactivado")

    else:
        # ---------------------------------------------
        # Bloque para acceso denegado (valido == False)
        # ---------------------------------------------
        print("❌ Acceso denegado")
        
        # Sin tocar el relé ni los LEDs, solo hacemos sonar el buzzer 3 veces
        for _ in range(3):
            sonar_buzzer(0.1)  # Zumbido breve de 0.1 segundos
            time.sleep(0.3)    # Pausa de 0.3 segundos entre cada zumbido

    # ------------------------------------------------
    # Limpieza final: apagar LED verde si quedara encendido
    # ------------------------------------------------
    led_ok.value(0)
    # No modificamos led_err ni rele ni buzzer aquí porque:
    # - En acceso autorizado, rele ya se puso en modo IN al desconectar.
    # - En acceso denegado, el buzzer se apaga al salir de sonar_buzzer().
    # - No se usa led_err en este flujo, así que no lo tocamos.

